package io.papermc.paper.registry.keys.tags;

import static net.kyori.adventure.key.Key.key;

import io.papermc.paper.annotation.GeneratedClass;
import io.papermc.paper.entity.poi.PoiType;
import io.papermc.paper.registry.RegistryKey;
import io.papermc.paper.registry.tag.TagKey;
import net.kyori.adventure.key.Key;
import org.jspecify.annotations.NullMarked;

/**
 * Vanilla tag keys for {@link RegistryKey#POINT_OF_INTEREST_TYPE}.
 *
 * @apiNote The fields provided here are a direct representation of
 * what is available from the vanilla game source. They may be
 * changed (including removals) on any Minecraft version
 * bump, so cross-version compatibility is not provided on the
 * same level as it is on most of the other API.
 */
@SuppressWarnings({
        "unused",
        "SpellCheckingInspection"
})
@NullMarked
@GeneratedClass
public final class PoiTypeTagKeys {
    /**
     * {@code #minecraft:acquirable_job_site}
     *
     * @apiNote This field is version-dependant and may be removed in future Minecraft versions
     */
    public static final TagKey<PoiType> ACQUIRABLE_JOB_SITE = create(key("acquirable_job_site"));

    /**
     * {@code #minecraft:bee_home}
     *
     * @apiNote This field is version-dependant and may be removed in future Minecraft versions
     */
    public static final TagKey<PoiType> BEE_HOME = create(key("bee_home"));

    /**
     * {@code #minecraft:village}
     *
     * @apiNote This field is version-dependant and may be removed in future Minecraft versions
     */
    public static final TagKey<PoiType> VILLAGE = create(key("village"));

    private PoiTypeTagKeys() {
    }

    /**
     * Creates a tag key for {@link PoiType} in the registry {@code minecraft:point_of_interest_type}.
     *
     * @param key the tag key's key
     * @return a new tag key
     */
    public static TagKey<PoiType> create(final Key key) {
        return TagKey.create(RegistryKey.POINT_OF_INTEREST_TYPE, key);
    }
}
